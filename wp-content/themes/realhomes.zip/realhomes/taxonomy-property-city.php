<?php

// Use Common Taxonomy Template
get_template_part("template-parts/common-taxonomy");