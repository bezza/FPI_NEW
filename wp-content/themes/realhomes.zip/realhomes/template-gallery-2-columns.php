<?php
/*
*   Template Name: Gallery 2 Columns Template
*/

global $gallery_name;
$gallery_name = 'gallery-2-columns';

global $gallery_image_size;
$gallery_image_size = 'gallery-two-column-image';

get_template_part('template-parts/gallery');