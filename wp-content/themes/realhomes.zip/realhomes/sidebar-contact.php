<div class="span3 sidebar-wrap">

    <!-- Sidebar -->
    <aside class="sidebar">
        <?php
        if ( ! dynamic_sidebar( 'contact-sidebar' ) ) :
        endif;
        ?>
    </aside><!-- End Sidebar -->

</div>