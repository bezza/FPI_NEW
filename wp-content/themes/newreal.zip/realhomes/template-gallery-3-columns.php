<?php
/*
*   Template Name: Gallery 3 Columns Template
*/

global $gallery_name;
$gallery_name = 'gallery-3-columns';

global $gallery_image_size;
$gallery_image_size = 'gallery-two-column-image';

get_template_part('template-parts/gallery');