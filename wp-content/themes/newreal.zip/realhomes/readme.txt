Please Read Documentation for Detailed Instructions.

You can submit a support ticket at http://support.inspirythemes.com/ if you need any help.

For General WordPress Issues you can search your issue in Google. As there are thousands of helping articles and forum threads out there to help WordPress users.

# this is test change

# this is change is added through sample-branch

# THIS IS MY XYZ FIX